<!DOCTYPE html>
<html>
<head>
    <title>Email Test</title>
</head>
<body>
    <h2>Hello, {{ $details['name'] }}</h2>
    <p>This is a test email from Laravel.</p>
    <p>Message: {{ $details['message'] }}</p>
</body>
</html>
